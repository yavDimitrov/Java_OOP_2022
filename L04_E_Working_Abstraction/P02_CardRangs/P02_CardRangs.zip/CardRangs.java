package L04_E_Working_Abstraction.P02_CardRangs;

public enum CardRangs {
    ACE, TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE, TEN, JACK, QUEEN, KING;
}
