package L04_E_Working_Abstraction.jediGalaxy;

public class Galaxy {
    private StarField field;

    public Galaxy(StarField field) {
        this.field = field;
    }
}
