package L04_E_Working_Abstraction.P04_TrafficLight;

public enum Color {
    RED,
    GREEN,
    YELLOW;


}
