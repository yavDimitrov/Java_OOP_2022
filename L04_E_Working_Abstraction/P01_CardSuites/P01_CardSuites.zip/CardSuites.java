package L04_E_Working_Abstraction.P01_CardSuites;

public enum CardSuites {
    CLUBS, DIAMONDS, HEARTS, SPADES;
}
